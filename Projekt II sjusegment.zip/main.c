/********************************************************************************
* main.c: Demonstration av inbyggt system innefattande 7-segmentsdisplayer.
*         Timerkrets Timer 1 anv�nds f�r att r�kna upp befintligt tal p�
*         7-segmentsdisplayerna en g�ng per sekund.
          En tryckknapp ansluten till pin 11 anv�nds som en start/stopp-signal
          f�r att starta eller stoppa uppr�kning.
          En tryckknapp ansluten till pin 12 anv�nds f�r att toggla
          uppr�kningsriktningen mellan upp och ned.
          En tryckknapp ansluten till pin 13 anv�nds som av/p�-signal f�r att
          t�nda/sl�cka 7-segmentsdisplayerna.
          �ven om 7-segmentsdisplayerna �r sl�ckta ska uppr�kning ske om detta �r
          aktiverat.
********************************************************************************/
#include "timer.h"
#include "wdt.h"
#include "display.h"
#include "header.h"
#include "button.h"


struct button b1, b2, b3;
struct timer timer0;

/********************************************************************************
* setup: Initierar systemet.
********************************************************************************/
static inline void setup(void)
{
	wdt_init(WDT_TIMEOUT_1024_MS);
	wdt_enable_interrupt();
	
	button_init(&b1,11);
	button_init(&b2,12);
	button_init(&b3,13);
	
	button_enable_interrupt(&b1);
	button_enable_interrupt(&b2);
	button_enable_interrupt(&b3);

	display_init();
	timer_init(&timer0, TIMER_SEL_0, 300);
	
	return;
}

/********************************************************************************
* main: Initierar systemet vid start. Uppr�kning sker sedan kontinuerligt
*       av talet p� 7-segmentsdisplayerna en g�ng per sekund. 
********************************************************************************/
int main(void)
{
   setup();
   
   while (1)
   {
      wdt_reset();
   }

   return 0;
}

