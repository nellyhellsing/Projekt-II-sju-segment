#ifndef HEADER_H_
#define HEADER_H_

#include "timer.h"
#include "wdt.h"
#include "display.h"
/* Externa struktar */
extern struct button b1, b2, b3;

extern struct timer timer0;


#endif /* HEADER_H_ */